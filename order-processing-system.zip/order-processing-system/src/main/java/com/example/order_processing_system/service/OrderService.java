package com.example.order_processing_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order_processing_system.Entity.Order;
import com.example.order_processing_system.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
    private OrderRepository orderRepository;

    @Autowired
    private MQSender mqSender;
    
    public Order createOrder(Order order) {
        Order saved = orderRepository.save(order);
        mqSender.send(saved);
        return saved;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
	
	
	

}
