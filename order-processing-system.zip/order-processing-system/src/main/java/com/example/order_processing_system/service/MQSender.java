package com.example.order_processing_system.service;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.order_processing_system.Entity.Order;


@Service
public class MQSender {
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@Value("${order.queue.name}")
    private String queueName;
	
	public void send(Order order) {
		rabbitTemplate.convertAndSend(queueName, order);
	}

}
