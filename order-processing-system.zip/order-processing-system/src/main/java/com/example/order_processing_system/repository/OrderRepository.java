package com.example.order_processing_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.order_processing_system.Entity.Order;

public interface OrderRepository extends JpaRepository<Order,String> {
	
	

}
